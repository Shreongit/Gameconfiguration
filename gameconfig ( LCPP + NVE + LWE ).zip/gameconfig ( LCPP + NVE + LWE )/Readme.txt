Ultimate Gameconfig for GTA V (v1.0.3889) — LCPP + NVE + Heavy Vegetation
Specially tuned gameconfig.xml built for Grand Theft Auto V Build 1.0.3889, 
designed to run heavy map expansions, graphics overhauls, and dense vegetation mods simultaneously without memory or pool crashes.



Tested & Compatible Mod Stack:

• 🏙️ Map: Liberty City Preservation Project (LCPP + HD Textures)
• 🌍 Graphics: NaturalVision Evolved (Razed Mods)
• 🌴 Vegetation & World: Lively World Expansion (LWE V3.0)
• 🌲 Vegetation: Forests of San Andreas: Revised



Requirements: Heap Adjuster (set to 2000MB+), Packfile Limit Adjuster (set to 65536), and OpenIV (mods/update/update.rpf/common/data/).